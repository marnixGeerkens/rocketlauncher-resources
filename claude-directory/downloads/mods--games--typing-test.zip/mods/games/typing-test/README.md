# typing-test

Typing test above the Claude Code prompt, for the minutes Claude spends working: retype a line of code as fast as you can. The game pauses and its status line says so when Claude finishes the turn, so you never miss a reply. Playing costs no tokens: the mod answers every key and click itself.

> A single game split out of [sezaakgun/cc-arcade](https://github.com/sezaakgun/cc-arcade) (MIT, by Seza Akgün). Want all nine games, a picker and the pet in one plugin? Install `games/cc-arcade` instead.

## Play

1. `/typing` opens the board above the prompt (`/typing stop` or the `close` button closes it).
2. **Click the board** to give it the keyboard; **Esc** gives the keyboard back to the prompt.
3. type the line shown. Correct characters turn green; a wrong one shows on red until you backspace it. Tab skips to another line, Enter starts the next one after a finished line.

Your best score is kept in the plugin's store across sessions.

## Install

```sh
npx claude-code-templates@latest --mod games/typing-test
claude
```

It is written to `.claude/skills/typing-test/`, which Claude Code auto-loads as `typing-test@skills-dir`. For one session with hot reload: `claude --plugin-dir .claude/skills/typing-test`.

## Requirements

- Claude Code 2.1.287 or later (mods are on by default from that version).
- An interactive terminal that reports the mouse. Nothing draws in `claude -p`, the desktop app or mobile.
- A terminal font with box-drawing and block characters.

Clones of the genre, not affiliated with or endorsed by the original publishers.
